var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy~",
  1: "abcdefghiklmnoprstuvwxy",
  2: "abcdfghiklmnoprstuvw",
  3: "abcdefghiklmnopqrstuvwxy~",
  4: "abcdefghiklmnopqrstuvwxy",
  5: "abcdefgilmnoprstuv",
  6: "bcdeflmopst",
  7: "bcdehimnprst",
  8: "i",
  9: "bgmps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "型定義",
  6: "列挙型",
  7: "列挙値",
  8: "フレンド",
  9: "マクロ定義"
};

