var searchData=
[
  ['ballstatus',['BallStatus',['../d9/d49/types_8h.html#ad1c70738c6188d30f3ef0010055c5762',1,'rcsc']]],
  ['bitmask',['BitMask',['../d1/db6/classrcsc_1_1AudioCodec.html#ae4c1487b75af8de48cf11f87711c03cc',1,'rcsc::AudioCodec']]]
];
