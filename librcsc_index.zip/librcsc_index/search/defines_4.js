var searchData=
[
  ['say_5fcharacters',['SAY_CHARACTERS',['../d9/d49/types_8h.html#a98611620cce577ba4598d5827538dbb2',1,'types.h']]]
];
