var searchData=
[
  ['g_5fbuffer_5fsize',['G_BUFFER_SIZE',['../df/db4/coach__debug__client_8cpp.html#a9475f96e7538135a86ab2e97912b18c1',1,'G_BUFFER_SIZE():&#160;coach_debug_client.cpp'],['../d3/d30/logger_8cpp.html#a9475f96e7538135a86ab2e97912b18c1',1,'G_BUFFER_SIZE():&#160;logger.cpp'],['../d2/d3d/debug__client_8cpp.html#a9475f96e7538135a86ab2e97912b18c1',1,'G_BUFFER_SIZE():&#160;debug_client.cpp']]]
];
