var searchData=
[
  ['init',['INIT',['../df/df1/classrcsc_1_1PlayerCommand.html#a1c2ac752ebfd0f0591f29dc15a574783a3eed11e16bbd501323afb2d0369e7a94',1,'rcsc::PlayerCommand::INIT()'],['../dd/d64/classrcsc_1_1TrainerCommand.html#ac2256f6295cf6d0eee8e9d295d807ecca8e9df0b35d61a91e119990206421cc89',1,'rcsc::TrainerCommand::INIT()']]]
];
