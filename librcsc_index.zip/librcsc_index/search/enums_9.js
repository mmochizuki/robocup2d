var searchData=
[
  ['sideid',['SideID',['../d9/d49/types_8h.html#a2a70a4d65908a0daca501287266272d9',1,'rcsc']]],
  ['sidetype',['SideType',['../df/d75/classrcsc_1_1Formation.html#aa5178aecbd2a14b9a11a79429689c5c0',1,'rcsc::Formation::SideType()'],['../d9/d38/classrcsc_1_1PlayerAttentiontoCommand.html#a710c9790b823ae50d4f76eb45288b265',1,'rcsc::PlayerAttentiontoCommand::SideType()'],['../d8/d09/classrcsc_1_1PlayerEarCommand.html#afcac3d06f10c786366f4f2c94292a1fc',1,'rcsc::PlayerEarCommand::SideType()']]],
  ['sockettype',['SocketType',['../d0/df3/classrcsc_1_1BasicSocket.html#aaafaa25d92ad888728e6e7bb9fc52037',1,'rcsc::BasicSocket']]],
  ['strategy',['Strategy',['../d4/d94/classrcsc_1_1gzfilebuf.html#a0283ac4a88126fcf079c13e8697dbaab',1,'rcsc::gzfilebuf']]],
  ['synchtype',['SynchType',['../dd/dfe/classrcsc_1_1SeeState.html#a911966d7e80d9738f761420ba590fd0b',1,'rcsc::SeeState']]]
];
